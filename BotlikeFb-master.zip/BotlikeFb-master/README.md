# BotlikeFb

#Run
```
pkg install php
cd Botlike
php botlike.php
```

# Tutorial Blog
```
https://senitopeng.xyz
```
